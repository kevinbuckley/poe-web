(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_1cb9f77b._.js",
  "static/chunks/app_(session)_[id]_page_tsx_7695cffd._.js"
],
    source: "dynamic"
});
