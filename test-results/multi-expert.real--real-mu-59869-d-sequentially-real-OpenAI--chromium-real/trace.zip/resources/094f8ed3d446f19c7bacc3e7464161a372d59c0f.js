(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_582279a2._.js",
  "static/chunks/05d5a_next_dist_compiled_react-dom_b0887cf2._.js",
  "static/chunks/05d5a_next_dist_compiled_next-devtools_index_c25960e9.js",
  "static/chunks/05d5a_next_dist_compiled_4e7795c4._.js",
  "static/chunks/05d5a_next_dist_client_f20c90b1._.js",
  "static/chunks/05d5a_next_dist_3aac09b9._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
